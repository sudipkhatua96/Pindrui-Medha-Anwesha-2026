
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AppView, StudentResult, YearArchive, Notice, HostCredential } from './types';
import { MOCK_ARCHIVES, MOCK_NOTICES } from './constants';
import * as databaseService from './services/databaseService';
import * as authService from './services/authService';
import AiAssistant from './components/AiAssistant';
import Modal from './components/common/Modal';

// Helper to get local date string YYYY-MM-DD
const getLocalDateString = (date: Date | string) => {
    try {
        const d = new Date(date);
        if (isNaN(d.getTime())) return new Date().toISOString().split('T')[0];
        const offset = d.getTimezoneOffset();
        const localDate = new Date(d.getTime() - (offset * 60 * 1000));
        return localDate.toISOString().split('T')[0];
    } catch (e) {
        return new Date().toISOString().split('T')[0];
    }
};

const Header: React.FC<{ onMenuClick: () => void, logoUrl: string, isScrolled: boolean, toggleTheme: () => void, isDarkMode: boolean }> = ({ onMenuClick, logoUrl, isScrolled, toggleTheme, isDarkMode }) => (
    <header className={`bg-white/90 dark:bg-slate-900/90 px-4 flex justify-between items-center fixed top-0 left-0 right-0 z-30 backdrop-blur-md transition-all duration-300 ${isScrolled ? 'shadow-lg h-14' : 'shadow-md h-16 sm:h-20'}`}>
        {/* Logo and Site Name */}
        <div className="flex items-center space-x-2 sm:space-x-3 cursor-pointer shrink-0" onClick={() => window.location.search = ''}>
            {logoUrl ? <img src={logoUrl} alt="Medha Anwesha Logo" className={`object-contain transition-all duration-300 ${isScrolled ? 'h-8 w-8' : 'h-10 w-10'}`}/> : <div className={`bg-gray-200 rounded-full transition-all duration-300 ${isScrolled ? 'h-8 w-8' : 'h-10 w-10'}`}></div>}
            <h1 className={`font-bold text-primary-600 dark:text-primary-400 transition-all duration-300 hidden md:block ${isScrolled ? 'text-lg' : 'text-xl md:text-2xl'}`}>Pindrui Medha Anwesha</h1>
            <h1 className={`font-bold text-primary-600 dark:text-primary-400 md:hidden ${isScrolled ? 'text-base' : 'text-lg'}`}>Pindrui</h1>
        </div>

        {/* Moving Watermark Container - Centered in Taskbar */}
        <div className="flex-1 flex items-center justify-center overflow-hidden h-full px-2 sm:px-6">
            <div className="w-full max-w-2xl bg-gradient-to-r from-transparent via-primary-500/10 to-transparent dark:via-primary-400/5 rounded-full py-1 overflow-hidden relative border-x border-primary-500/20">
                <div className="whitespace-nowrap animate-marquee-rtl flex">
                    <span className="text-[10px] sm:text-xs font-bold text-primary-700 dark:text-primary-300 uppercase tracking-widest px-12">
                         <i className="fas fa-user-shield mr-2"></i>Admin : SUDIP KHATUA <span className="mx-4 text-gray-300">|</span> <i className="fas fa-globe mr-2"></i>For Creating Website Contact: 9647730663
                    </span>
                    <span className="text-[10px] sm:text-xs font-bold text-primary-700 dark:text-primary-300 uppercase tracking-widest px-12">
                         <i className="fas fa-user-shield mr-2"></i>Admin : SUDIP KHATUA <span className="mx-4 text-gray-300">|</span> <i className="fas fa-globe mr-2"></i>For Creating Website Contact: 9647730663
                    </span>
                </div>
            </div>
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-1 sm:space-x-4 shrink-0">
            <button
                onClick={toggleTheme}
                className="text-gray-700 dark:text-gray-300 text-lg w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                aria-label="Toggle dark mode"
            >
                <i className={`fas transition-transform duration-300 ease-in-out ${isDarkMode ? 'fa-sun rotate-90 text-amber-500' : 'fa-moon text-primary-500'}`}></i>
            </button>
            <button onClick={onMenuClick} className="text-gray-700 dark:text-gray-300 text-xl w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                <i className="fas fa-bars"></i>
            </button>
        </div>
    </header>
);

const SideMenu: React.FC<{ isOpen: boolean; onClose: () => void; setView: (view: AppView) => void, toggleTheme: () => void, isDarkMode: boolean, isDiscoMode: boolean, toggleDiscoMode: () => void, isZoomEffectEnabled: boolean, toggleZoomEffect: () => void }> = ({ isOpen, onClose, setView, toggleTheme, isDarkMode, isDiscoMode, toggleDiscoMode, isZoomEffectEnabled, toggleZoomEffect }) => {
    const navigate = (view: AppView) => {
        setView(view);
        onClose();
    };
    
    const handleShare = () => {
        const url = window.location.href;
        if (navigator.share) {
            navigator.share({
                title: 'Pindrui Medha Anwesha',
                text: 'Check out the Medha Anwesha results and updates!',
                url: url,
            });
        } else {
            navigator.clipboard.writeText(url);
            alert('Link copied to clipboard!');
        }
        onClose();
    };
    
    const menuLinkClasses = "cursor-pointer py-3 px-4 rounded-lg font-semibold text-gray-700 dark:text-gray-200 hover:bg-primary-500/10 hover:text-primary-600 dark:hover:text-primary-300 transition-all duration-200 flex items-center space-x-3 transform hover:translate-x-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-gray-800";

    return (
        <>
            <div className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose}></div>
            <div className={`fixed top-0 right-0 h-full w-72 bg-white dark:bg-gray-800 shadow-lg z-50 transform transition-transform ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                    <h2 className="text-lg font-bold text-gray-800 dark:text-gray-100">Menu</h2>
                    <button onClick={onClose} className="text-gray-500 dark:text-gray-400"><i className="fas fa-times"></i></button>
                </div>
                <nav className="p-4 flex flex-col h-full">
                    <a onClick={() => navigate(AppView.NOTICES)} className={menuLinkClasses}><i className="fas fa-bullhorn w-5"></i><span>Notices</span></a>
                    <a onClick={() => navigate(AppView.ARCHIVE_RESULTS)} className={menuLinkClasses}><i className="fas fa-archive w-5"></i><span>Year-wise Results</span></a>
                    <a onClick={() => navigate(AppView.ARCHIVE_QUESTIONS)} className={menuLinkClasses}><i className="fas fa-file-alt w-5"></i><span>Question Papers</span></a>
                    <a onClick={() => navigate(AppView.UPDATES)} className={menuLinkClasses}><i className="fas fa-star w-5"></i><span>Puja Updates</span></a>
                    <a onClick={handleShare} className={menuLinkClasses}><i className="fas fa-share-alt w-5"></i><span>Share Link</span></a>
                    <div className="mt-auto pt-4 border-t dark:border-gray-700 space-y-2">
                        <button onClick={toggleTheme} className="w-full text-left py-3 px-4 rounded-lg font-semibold text-gray-700 dark:text-gray-200 hover:bg-primary-500/10 hover:text-primary-600 dark:hover:text-primary-300 transition-all duration-200 flex justify-between items-center">
                            <span>{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>
                            <i className={`fas ${isDarkMode ? 'fa-sun' : 'fa-moon'}`}></i>
                        </button>
                         <button onClick={toggleDiscoMode} className={`w-full text-left py-3 px-4 rounded-lg font-semibold transition-all duration-200 flex justify-between items-center ${isDiscoMode ? 'bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow-lg' : 'text-gray-700 dark:text-gray-200 hover:bg-primary-500/10 hover:text-primary-600 dark:hover:text-primary-300'}`}>
                            <span>{isDiscoMode ? 'Stop the Party' : 'Disco Mode'}</span>
                            <i className={`fas ${isDiscoMode ? 'fa-music' : 'fa-compact-disc'}`}></i>
                        </button>
                        <button onClick={toggleZoomEffect} className="w-full text-left py-3 px-4 rounded-lg font-semibold text-gray-700 dark:text-gray-200 hover:bg-primary-500/10 hover:text-primary-600 dark:hover:text-primary-300 transition-all duration-200 flex justify-between items-center">
                            <span>{isZoomEffectEnabled ? 'Disable Magnify' : 'Enable Magnify'}</span>
                            <i className={`fas ${isZoomEffectEnabled ? 'fa-search-minus' : 'fa-search-plus'}`}></i>
                        </button>
                    </div>
                </nav>
            </div>
        </>
    );
};

const StyledButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { icon?: string }> = ({ children, icon, className, ...props }) => (
    <button
        className={`bg-gradient-to-r from-primary-500 to-primary-600 text-white font-semibold py-2 px-5 rounded-lg shadow-md transform transition-all duration-300 ease-in-out hover:shadow-xl hover:from-primary-600 hover:to-primary-700 hover:-translate-y-1 hover:scale-105 focus:outline-none focus-visible:shadow-xl focus-visible:from-primary-600 focus-visible:to-primary-700 focus-visible:-translate-y-1 focus-visible:scale-105 flex items-center justify-center space-x-2 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none ${className}`}
        {...props}
    >
        {icon && <i className={icon}></i>}
        <span>{children}</span>
    </button>
);

const ResultsView: React.FC<{ results: StudentResult[], onBack: () => void, isArchive?: boolean }> = ({ results, onBack, isArchive = false }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedClass, setSelectedClass] = useState('all');

    const availableClasses = Array.from({ length: 10 }, (_, i) => i + 1); // Classes 1 to 10
    
    // Check URL params for initial state
    useEffect(() => {
        if (!isArchive) {
            const params = new URLSearchParams(window.location.search);
            const classParam = params.get('class');
            if (classParam && (classParam === 'all' || availableClasses.includes(parseInt(classParam)))) {
                setSelectedClass(classParam);
            }
        }
    }, [isArchive]);

    const handleClassChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newVal = e.target.value;
        setSelectedClass(newVal);
        
        // Update URL to make it shareable
        if (!isArchive) {
            const params = new URLSearchParams(window.location.search);
            if (newVal === 'all') {
                params.delete('class');
            } else {
                params.set('class', newVal);
            }
            const newUrl = `${window.location.pathname}?${params.toString()}`;
            window.history.replaceState(null, '', newUrl);
        }
    };

    // 1. Filter by Class first
    let classBasedResults = Array.isArray(results) ? [...results] : [];
    if (selectedClass !== 'all') {
        classBasedResults = classBasedResults.filter(r => r.class.toString() === selectedClass);
    }

    // 2. Sort by Marks (Descending) to establish a new Rank order for this view
    classBasedResults.sort((a, b) => b.marks - a.marks);

    // 3. Assign display rank with tie-awareness (Competition Ranking)
    // If students have same marks, they share the same rank.
    // The rank of the next student will be their positional serial number (index + 1).
    const resultsWithRank = classBasedResults.map((result, index, sortedArr) => {
        let displayRank = index + 1;
        if (index > 0 && result.marks === sortedArr[index - 1].marks) {
            // Find the rank of the first person with these marks in the sorted array
            const firstTiedIndex = sortedArr.findIndex(r => r.marks === result.marks);
            displayRank = firstTiedIndex + 1;
        }
        return {
            ...result,
            displayRank
        };
    });

    // 4. Filter by search term
    const filteredResults = resultsWithRank.filter(r => 
        r.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        r.admitNumber.includes(searchTerm) ||
        r.class.toString().includes(searchTerm)
    );

    return (
        <div className={`p-4 md:p-8 animate-content-fade-in`}>
             {!isArchive && (
                <StyledButton onClick={onBack} icon="fas fa-arrow-left" className="mb-6">
                    Back to Home
                </StyledButton>
             )}
            <h2 className="text-3xl font-bold mb-2 text-center text-gray-800 dark:text-gray-100">Exam Results</h2>
            <p className="text-center text-gray-600 dark:text-gray-400 mb-6">Showing: {filteredResults.length} Record(s)</p>
            <div className="mb-6 max-w-2xl mx-auto flex flex-col md:flex-row gap-4">
                <input
                    type="text"
                    placeholder="Search by name, admit number..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="form-input w-full p-3 rounded-lg border-2 border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                />
                 <select
                    aria-label="Filter by class"
                    value={selectedClass}
                    onChange={handleClassChange}
                    className="form-select md:w-48 w-full p-3 rounded-lg border-2 border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                >
                    <option value="all">All Classes</option>
                    {availableClasses.map(cls => (
                        <option key={cls} value={cls}>{`Class ${cls}`}</option>
                    ))}
                </select>
            </div>
            <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg">
                <table className="w-full text-left">
                    <thead className="bg-gray-100 dark:bg-gray-700">
                        <tr>
                            <th className="p-4 font-bold text-gray-600 dark:text-gray-300">{selectedClass === 'all' ? 'Global Rank' : 'Class Rank'}</th>
                            <th className="p-4 font-bold text-gray-600 dark:text-gray-300">Admit No.</th>
                            <th className="p-4 font-bold text-gray-600 dark:text-gray-300">Name</th>
                            <th className="p-4 font-bold text-gray-600 dark:text-gray-300">Class</th>
                            <th className="p-4 font-bold text-gray-600 dark:text-gray-300">Marks</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredResults.map(result => (
                            <tr key={result.admitNumber} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600/20 transition-all duration-150 ease-in-out transform hover:-translate-y-px hover:shadow-sm">
                                <td className="p-4 text-gray-800 dark:text-gray-200 font-bold">
                                    {result.displayRank}
                                </td>
                                <td className="p-4 text-gray-800 dark:text-gray-200">{result.admitNumber}</td>
                                <td className="p-4 text-gray-800 dark:text-gray-200">{result.name}</td>
                                <td className="p-4 text-gray-800 dark:text-gray-200">{result.class}</td>
                                <td className="p-4 text-gray-800 dark:text-gray-200">{result.marks}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredResults.length === 0 && <p className="p-4 text-center text-gray-500 dark:text-gray-400">No results found.</p>}
            </div>
        </div>
    );
};

const HostLogin: React.FC<{ onLoginSuccess: () => void, onBack: () => void, onForgotPassword: () => void, onCreateAccount: () => void }> = ({ onLoginSuccess, onBack, onForgotPassword, onCreateAccount }) => {
    const [step, setStep] = useState(1);
    const [mobile, setMobile] = useState('');
    const [password, setPassword] = useState('');
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleLogin = async () => {
        setError('');
        setIsLoading(true);
        try {
            const host = await databaseService.getHostByMobile(mobile);
            if (host && host.password === password) {
                await authService.sendOtp(mobile);
                setStep(2);
            } else {
                setError('Invalid mobile number or password.');
            }
        } catch (e) {
            setError('An error occurred. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleOtp = async () => {
        setError('');
        setIsLoading(true);
        try {
            const isValid = await authService.verifyOtp(otp);
            if (isValid) {
                onLoginSuccess();
            } else {
                setError('Invalid or expired OTP.');
            }
        } catch(e) {
             setError('An error occurred during OTP verification.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col items-center justify-center p-4 animate-content-fade-in">
             <button onClick={onBack} className="self-start mb-6 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 py-2 px-4 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors flex items-center">
                <i className="fas fa-arrow-left mr-2"></i>Back
            </button>
            <div className="w-full max-w-md bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:text-gray-100">Host Access</h2>
                {error && <p className="bg-red-100 text-red-700 p-3 rounded-md mb-4 text-center">{error}</p>}
                {step === 1 ? (
                    <div className="space-y-4">
                        <input type="text" placeholder="Mobile Number" value={mobile} onChange={e => setMobile(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                        <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                        <StyledButton onClick={handleLogin} disabled={isLoading} className="w-full">
                            {isLoading ? <i className="fas fa-spinner fa-pulse"></i> : 'Get OTP'}
                        </StyledButton>
                        <div className="text-sm text-center text-gray-500 dark:text-gray-400 flex justify-between">
                            <a href="#" onClick={(e) => { e.preventDefault(); alert('Please contact the committee administration to recover your mobile number.'); }} className="hover:underline">Forgot Number?</a>
                            <a href="#" onClick={(e) => { e.preventDefault(); onForgotPassword(); }} className="hover:underline">Forgot Password?</a>
                        </div>
                        <div className="text-center pt-2">
                            <a href="#" onClick={(e) => { e.preventDefault(); onCreateAccount(); }} className="text-primary-600 dark:text-primary-400 hover:underline">Create New Account</a>
                        </div>
                    </div>
                ) : (
                     <div className="space-y-4">
                        <p className="text-center text-gray-600 dark:text-gray-400">An OTP has been sent. Check the developer console.</p>
                        <input type="text" placeholder="Enter OTP" value={otp} onChange={e => setOtp(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                        <StyledButton onClick={handleOtp} disabled={isLoading} className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700">
                             {isLoading ? <i className="fas fa-spinner fa-pulse"></i> : 'Verify & Login'}
                        </StyledButton>
                    </div>
                )}
            </div>
        </div>
    );
};

const HostSignUp: React.FC<{ onRegister: (creds: HostCredential) => void, onBack: () => void }> = ({ onRegister, onBack }) => {
    const [mobile, setMobile] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleRegister = async () => {
        setError('');

        if (!mobile || !password || !confirmPassword) {
            setError('Please fill all fields.');
            return;
        }

        const mobileRegex = /^\d{10}$/;
        if (!mobileRegex.test(mobile)) {
            setError('Mobile number must be exactly 10 digits.');
            return;
        }

        setIsLoading(true);
        try {
            const existingHost = await databaseService.getHostByMobile(mobile);
            if (existingHost) {
                setError('This mobile number is already registered.');
                setIsLoading(false);
                return;
            }

            const passwordErrors = [];
            if (password.length < 8) {
                passwordErrors.push('be at least 8 characters long');
            }
            if (!/[a-z]/.test(password)) {
                passwordErrors.push('contain at least one lowercase letter (a-z)');
            }
            if (!/[A-Z]/.test(password)) {
                passwordErrors.push('contain at least one uppercase letter (A-Z)');
            }
            if (!/\d/.test(password)) {
                passwordErrors.push('contain at least one number (0-9)');
            }
            if (!/[@$!%*?&]/.test(password)) {
                passwordErrors.push('contain at least one special character (@$!%*?&)');
            }

            if (passwordErrors.length > 0) {
                setError(`Password must:\n- ${passwordErrors.join('\n- ')}`);
                setIsLoading(false);
                return;
            }

            if (password !== confirmPassword) {
                setError('Passwords do not match.');
                setIsLoading(false);
                return;
            }

            setError('');
            onRegister({ mobile, password });
        } catch (e) {
            setError('An error occurred during registration check.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col items-center justify-center p-4 animate-content-fade-in">
            <button onClick={onBack} className="self-start mb-6 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 py-2 px-4 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors flex items-center">
                <i className="fas fa-arrow-left mr-2"></i>Back to Login
            </button>
            <div className="w-full max-w-md bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:text-gray-100">Create Host Account</h2>
                {error && <p className="bg-red-100 text-red-700 p-3 rounded-md mb-4 text-center whitespace-pre-wrap">{error}</p>}
                <div className="space-y-4">
                    <input type="text" placeholder="Mobile Number (10 digits)" value={mobile} onChange={e => setMobile(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                    <input type="password" placeholder="Password (min. 8, A-Z, a-z, 0-9, symbol)" value={password} onChange={e => setPassword(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                    <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                    <StyledButton onClick={handleRegister} disabled={isLoading} className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700">
                        {isLoading ? <i className="fas fa-spinner fa-pulse"></i> : 'Register'}
                    </StyledButton>
                </div>
            </div>
        </div>
    );
};

const ForgotPasswordView: React.FC<{ onPasswordReset: (mobile: string, password: string) => void, onBack: () => void }> = ({ onPasswordReset, onBack }) => {
    const [mobile, setMobile] = useState('');
    const [otp, setOtp] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [step, setStep] = useState(1);
    const [isLoading, setIsLoading] = useState(false);

    const handleVerifyMobile = async () => {
        setError('');
        setIsLoading(true);
        try {
            const host = await databaseService.getHostByMobile(mobile);
            if (host) {
                await authService.sendOtp(mobile);
                setStep(2);
            } else {
                setError('This mobile number is not registered.');
            }
        } catch (e) {
            setError('An error occurred. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleVerifyOtp = async () => {
         setError('');
         setIsLoading(true);
         try {
             const isValid = await authService.verifyOtp(otp);
             if (isValid) {
                 setStep(3);
             } else {
                 setError('Invalid or expired OTP.');
             }
         } catch(e) {
              setError('An error occurred during OTP verification.');
         } finally {
             setIsLoading(false);
         }
    };

    const handleReset = () => {
        setError('');
        
        // Validation logic matching HostSignUp
        const passwordErrors = [];
        if (newPassword.length < 8) {
            passwordErrors.push('be at least 8 characters long');
        }
        if (!/[a-z]/.test(newPassword)) {
            passwordErrors.push('contain at least one lowercase letter (a-z)');
        }
        if (!/[A-Z]/.test(newPassword)) {
            passwordErrors.push('contain at least one uppercase letter (A-Z)');
        }
        if (!/\d/.test(newPassword)) {
            passwordErrors.push('contain at least one number (0-9)');
        }
        if (!/[@$!%*?&]/.test(newPassword)) {
            passwordErrors.push('contain at least one special character (@$!%*?&)');
        }

        if (passwordErrors.length > 0) {
            setError(`Password must:\n- ${passwordErrors.join('\n- ')}`);
            return;
        }

        if (newPassword !== confirmPassword) {
            setError('Passwords do not match.');
            return;
        }
        
        onPasswordReset(mobile, newPassword);
    };

    return (
        <div className="flex flex-col items-center justify-center p-4 animate-content-fade-in">
            <button onClick={onBack} className="self-start mb-6 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 py-2 px-4 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors flex items-center">
                <i className="fas fa-arrow-left mr-2"></i>Back to Login
            </button>
            <div className="w-full max-w-md bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:text-gray-100">Reset Password</h2>
                {error && <p className="bg-red-100 text-red-700 p-3 rounded-md mb-4 text-center whitespace-pre-wrap">{error}</p>}
                
                {step === 1 && (
                    <div className="space-y-4 animate-content-fade-in">
                        <p className="text-center text-gray-600 dark:text-gray-400">Enter your registered mobile number. We will send an OTP.</p>
                        <input type="text" placeholder="Mobile Number" value={mobile} onChange={e => setMobile(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                        <StyledButton onClick={handleVerifyMobile} disabled={isLoading} className="w-full">
                             {isLoading ? <i className="fas fa-spinner fa-pulse"></i> : 'Get OTP'}
                        </StyledButton>
                    </div>
                )}

                {step === 2 && (
                    <div className="space-y-4 animate-content-fade-in">
                         <p className="text-center text-gray-600 dark:text-gray-400">Enter the OTP sent to {mobile}. (Check console)</p>
                         <input type="text" placeholder="Enter OTP" value={otp} onChange={e => setOtp(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                         <StyledButton onClick={handleVerifyOtp} disabled={isLoading} className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700">
                             {isLoading ? <i className="fas fa-spinner fa-pulse"></i> : 'Verify OTP'}
                         </StyledButton>
                         <button onClick={() => setStep(1)} className="w-full text-sm text-gray-500 hover:underline mt-2">Change Mobile Number</button>
                    </div>
                )}

                {step === 3 && (
                    <div className="space-y-4 animate-content-fade-in">
                        <p className="text-center text-gray-600 dark:text-gray-400">Create a new strong password.</p>
                        <input type="password" placeholder="New Password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                        <input type="password" placeholder="Confirm New Password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="form-input w-full p-3 rounded-md border-2 bg-gray-50 dark:bg-gray-700 dark:border-gray-600"/>
                        <StyledButton onClick={handleReset} className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700">Reset Password</StyledButton>
                    </div>
                )}
            </div>
        </div>
    );
};

const HostDashboard: React.FC<{ 
    results: StudentResult[];
    archives: YearArchive[];
    notices: Notice[];
    logo: string;
    headerImage: string;
    shareUrl: string;
    shareQr: string;
    onUpdateResults: (data: StudentResult[]) => void | Promise<void>;
    onUpdateArchives: (data: YearArchive[]) => void;
    onUpdateNotices: (data: Notice[]) => void | Promise<void>;
    onUpdateLogo: (url: string) => void;
    onUpdateHeaderImage: (url: string) => void;
    onUpdateShareUrl: (url: string) => void;
    onUpdateShareQr: (url: string) => void;
    onLogout: () => void;
    onBack: () => void;
}> = ({ results, archives, notices, logo, headerImage, shareUrl, shareQr, onUpdateResults, onUpdateArchives, onUpdateNotices, onUpdateLogo, onUpdateHeaderImage, onUpdateShareUrl, onUpdateShareQr, onLogout, onBack }) => {
    
    // Student States
    const [isStudentModalOpen, setStudentModalOpen] = useState(false);
    const [editingStudent, setEditingStudent] = useState<StudentResult | null | { admitNumber: string, name: string, class: number, marks: number, rank: 0 }>(null);
    const [isDeleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [deletingAdmitNumber, setDeletingAdmitNumber] = useState<string | null>(null);
    
    // Notice States
    const [isNoticeModalOpen, setNoticeModalOpen] = useState(false);
    const [editingNotice, setEditingNotice] = useState<Notice | null | { id: string, title: string, content: string, date: string }>(null);
    const [isNoticeDeleteConfirmOpen, setNoticeDeleteConfirmOpen] = useState(false);
    const [deletingNoticeId, setDeletingNoticeId] = useState<string | null>(null);
    const [isNoticePreview, setIsNoticePreview] = useState(false);
    const noticeContentRef = useRef<HTMLTextAreaElement>(null);

    const [actionLoading, setActionLoading] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedClass, setSelectedClass] = useState('all');

    const availableClasses = Array.from({ length: 10 }, (_, i) => i + 1);

    // --- Student Actions ---
    const handleOpenAddModal = async () => {
        setActionLoading('add');
        await new Promise(resolve => setTimeout(resolve, 600));
        setEditingStudent({ admitNumber: '', name: '', class: 1, marks: 0, rank: 0 });
        setStudentModalOpen(true);
        setActionLoading(null);
    };

    const handleOpenEditModal = async (student: StudentResult) => {
        setActionLoading(`edit-${student.admitNumber}`);
        await new Promise(resolve => setTimeout(resolve, 600));
        setEditingStudent(student);
        setStudentModalOpen(true);
        setActionLoading(null);
    };
    
    const handleDeleteStudent = (admitNumber: string) => {
        setDeletingAdmitNumber(admitNumber);
        setDeleteConfirmOpen(true);
    };
    
    const handleConfirmDelete = () => {
        if (!deletingAdmitNumber) return;
        const currentResults = Array.isArray(results) ? results : [];
        const updatedResults = currentResults.filter(s => s.admitNumber !== deletingAdmitNumber);
        onUpdateResults(updatedResults);
        setDeleteConfirmOpen(false);
        setDeletingAdmitNumber(null);
    };

    const handleSaveStudent = async () => {
        if (!editingStudent) return;
        if (!editingStudent.admitNumber || !editingStudent.name || !editingStudent.class || editingStudent.marks < 0) {
            alert('Please fill all fields correctly.');
            return;
        }
        setActionLoading('save');
        const currentResults = Array.isArray(results) ? results : [];
        let updatedResults;
        const isEditing = currentResults.some(r => r.admitNumber === editingStudent.admitNumber);
        if (isEditing) {
            updatedResults = currentResults.map(s => s.admitNumber === editingStudent.admitNumber ? { ...s, name: editingStudent.name, class: editingStudent.class, marks: editingStudent.marks } : s);
        } else {
            updatedResults = [...currentResults, editingStudent as StudentResult];
        }
        await onUpdateResults(updatedResults);
        setStudentModalOpen(false);
        setEditingStudent(null);
        setActionLoading(null);
    };

    // --- Notice Actions ---
    const handleOpenAddNoticeModal = () => {
        setEditingNotice({ id: '', title: '', content: '', date: getLocalDateString(new Date()) });
        setIsNoticePreview(false);
        setNoticeModalOpen(true);
    };

    const handleOpenEditNoticeModal = (notice: Notice) => {
        setEditingNotice({ ...notice, date: getLocalDateString(notice.date) });
        setIsNoticePreview(false);
        setNoticeModalOpen(true);
    };

    const handleDeleteNotice = (id: string) => {
        setDeletingNoticeId(id);
        setNoticeDeleteConfirmOpen(true);
    };

    const handleConfirmDeleteNotice = async () => {
        if (!deletingNoticeId) return;
        const currentNotices = Array.isArray(notices) ? notices : [];
        const updatedNotices = currentNotices.filter(n => n.id !== deletingNoticeId);
        await onUpdateNotices(updatedNotices);
        setNoticeDeleteConfirmOpen(false);
        setDeletingNoticeId(null);
    };

    const handleSaveNotice = async () => {
        if (!editingNotice || !editingNotice.title || !editingNotice.content || !editingNotice.date) {
            alert('Please fill all fields for the notice.');
            return;
        }

        setActionLoading('save-notice');
        const currentNotices = Array.isArray(notices) ? notices : [];
        let updatedNotices;
        if (editingNotice.id) {
            // Edit
            updatedNotices = currentNotices.map(n => n.id === editingNotice.id ? (editingNotice as Notice) : n);
        } else {
            // Create
            const newNotice = { ...editingNotice, id: Date.now().toString() } as Notice;
            updatedNotices = [newNotice, ...currentNotices];
        }

        await onUpdateNotices(updatedNotices);
        setNoticeModalOpen(false);
        setEditingNotice(null);
        setActionLoading(null);
    };

    // --- Rich Text Helper ---
    const injectFormatting = (startTag: string, endTag: string) => {
        const textarea = noticeContentRef.current;
        if (!textarea || !editingNotice) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = editingNotice.content;
        const before = text.substring(0, start);
        const selected = text.substring(start, end);
        const after = text.substring(end);

        const newContent = before + startTag + selected + endTag + after;
        setEditingNotice({ ...editingNotice, content: newContent });
        
        // Refocus and place cursor
        setTimeout(() => {
            textarea.focus();
            const newPos = start + startTag.length + selected.length + endTag.length;
            textarea.setSelectionRange(newPos, newPos);
        }, 0);
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, onUpdate: (url: string) => void) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 2 * 1024 * 1024) { // Increased to 2MB for QR codes
                alert("File too large! Please select an image smaller than 2MB.");
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => onUpdate(reader.result as string);
            reader.readAsDataURL(file);
        }
    };
    
    const studentToDelete = deletingAdmitNumber ? results.find(s => s.admitNumber === deletingAdmitNumber) : null;
    const noticeToDelete = deletingNoticeId ? notices.find(n => n.id === deletingNoticeId) : null;

    const filteredResults = (Array.isArray(results) ? results : []).filter(student => {
        const matchesClass = selectedClass === 'all' || student.class.toString() === selectedClass;
        const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              student.admitNumber.includes(searchTerm);
        return matchesClass && matchesSearch;
    });

    // Sort notices descending (latest first) for management
    const safeNotices = Array.isArray(notices) ? notices : [];
    const sortedNotices = [...safeNotices].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    const todayStr = getLocalDateString(new Date());

    return (
        <div className="p-4 md:p-8 space-y-8 animate-content-fade-in">
            <div className="flex justify-between items-center flex-wrap gap-4">
                <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Host Dashboard</h2>
                <div className="flex gap-3">
                    <StyledButton onClick={onBack} icon="fas fa-home" className="bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700">Back to Home</StyledButton>
                    <StyledButton onClick={onLogout} icon="fas fa-sign-out-alt" className="bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700">Logout</StyledButton>
                </div>
            </div>

            {/* Student Results Management */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
                <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
                    <h3 className="text-xl font-bold">Manage Student Results</h3>
                    <StyledButton 
                        onClick={handleOpenAddModal} 
                        disabled={!!actionLoading} 
                        icon={actionLoading === 'add' ? "fas fa-spinner fa-pulse" : "fas fa-plus"} 
                        className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                    >
                        {actionLoading === 'add' ? 'Loading...' : 'Add Student'}
                    </StyledButton>
                </div>
                
                <div className="mb-4 flex flex-col md:flex-row gap-4">
                     <input
                        type="text"
                        placeholder="Search by name or admit number..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-input flex-grow p-2 rounded-lg border-2 border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                    />
                    <select
                        aria-label="Filter by class"
                        value={selectedClass}
                        onChange={(e) => setSelectedClass(e.target.value)}
                        className="form-select md:w-48 w-full p-2 rounded-lg border-2 border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                    >
                        <option value="all">All Classes</option>
                        {availableClasses.map(cls => (
                            <option key={cls} value={cls}>{`Class ${cls}`}</option>
                        ))}
                    </select>
                    <button
                        onClick={() => { setSearchTerm(''); setSelectedClass('all'); }}
                        className="md:w-auto w-full px-4 py-2 bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors flex items-center justify-center font-medium shadow-sm"
                        title="Clear Search & Filters"
                    >
                        <i className="fas fa-times mr-2"></i>Clear
                    </button>
                </div>

                <div className="overflow-x-auto max-h-96">
                     <table className="w-full text-left">
                        <thead className="bg-gray-100 dark:bg-gray-700 sticky top-0">
                            <tr>
                                <th className="p-3 font-bold text-gray-600 dark:text-gray-300">Admit No.</th>
                                <th className="p-3 font-bold text-gray-600 dark:text-gray-300">Name</th>
                                <th className="p-3 font-bold text-gray-600 dark:text-gray-300">Class</th>
                                <th className="p-3 font-bold text-gray-600 dark:text-gray-300">Marks</th>
                                <th className="p-3 font-bold text-gray-600 dark:text-gray-300">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredResults.map(student => (
                                <tr key={student.admitNumber} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600/20 transition-all duration-150 ease-in-out transform hover:-translate-y-px hover:shadow-sm">
                                    <td className="p-3 text-gray-800 dark:text-gray-200">{student.admitNumber}</td>
                                    <td className="p-3 text-gray-800 dark:text-gray-200">{student.name}</td>
                                    <td className="p-3 text-gray-800 dark:text-gray-200">{student.class}</td>
                                    <td className="p-3 text-gray-800 dark:text-gray-200">{student.marks}</td>
                                    <td className="p-3 text-gray-800 dark:text-gray-200 space-x-2">
                                        <button onClick={() => handleOpenEditModal(student)} className="text-blue-500 hover:text-blue-700 transition-transform duration-200 transform hover:scale-125 focus:outline-none"><i className="fas fa-edit"></i></button>
                                        <button onClick={() => handleDeleteStudent(student.admitNumber)} className="text-red-500 hover:text-red-700 transition-transform duration-200 transform hover:scale-125 focus:outline-none"><i className="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Notice Management */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
                <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
                    <h3 className="text-xl font-bold">Manage Notices</h3>
                    <StyledButton onClick={handleOpenAddNoticeModal} icon="fas fa-bullhorn" className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700">Add Notice</StyledButton>
                </div>
                <div className="overflow-x-auto max-h-96">
                    {sortedNotices.length > 0 ? (
                        <table className="w-full text-left">
                            <thead className="bg-gray-100 dark:bg-gray-700 sticky top-0">
                                <tr>
                                    <th className="p-3 font-bold text-gray-600 dark:text-gray-300">Title</th>
                                    <th className="p-3 font-bold text-gray-600 dark:text-gray-300">Publication Date</th>
                                    <th className="p-3 font-bold text-gray-600 dark:text-gray-300 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sortedNotices.map(notice => {
                                    const isScheduled = notice.date > todayStr;
                                    return (
                                        <tr key={notice.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600/20 transition-all">
                                            <td className="p-3 text-gray-800 dark:text-gray-200 font-semibold flex items-center gap-2">
                                                {notice.title}
                                                {isScheduled && (
                                                    <span className="text-[10px] uppercase tracking-wider font-bold bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 px-1.5 py-0.5 rounded border border-blue-200 dark:border-blue-800 flex items-center gap-1">
                                                        <i className="fas fa-clock text-[9px]"></i> Scheduled
                                                    </span>
                                                )}
                                            </td>
                                            <td className="p-3 text-gray-800 dark:text-gray-200 font-medium">
                                                <span className={`px-2 py-1 rounded text-sm ${isScheduled ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300' : 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300'}`}>
                                                    {new Date(notice.date).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                                                </span>
                                            </td>
                                            <td className="p-3 text-gray-800 dark:text-gray-200 text-right space-x-3">
                                                <button onClick={() => handleOpenEditNoticeModal(notice)} className="text-blue-500 hover:text-blue-700 transform hover:scale-125 transition-transform" title="Edit Notice & Date"><i className="fas fa-edit"></i></button>
                                                <button onClick={() => handleDeleteNotice(notice.id)} className="text-red-500 hover:text-red-700 transform hover:scale-125 transition-transform" title="Delete Notice"><i className="fas fa-trash"></i></button>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    ) : (
                        <div className="text-center py-12 bg-gray-50 dark:bg-gray-700/30 rounded-lg border-2 border-dashed border-gray-200 dark:border-gray-600">
                            <i className="fas fa-bullhorn fa-3x text-gray-300 dark:text-gray-600 mb-4"></i>
                            <p className="text-gray-500 dark:text-gray-400 mb-6">No notices found. Start by creating one!</p>
                            <StyledButton onClick={handleOpenAddNoticeModal} icon="fas fa-plus">Create Your First Notice</StyledButton>
                        </div>
                    )}
                </div>
            </div>

            {/* Customization & Sharing Settings */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Visual Assets */}
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg space-y-6">
                    <h3 className="text-xl font-bold flex items-center gap-2"><i className="fas fa-palette text-primary-500"></i> Visual Branding</h3>
                    <div className="space-y-4">
                        <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-between">
                            <div>
                                <p className="font-bold text-sm">Organization Logo</p>
                                <p className="text-xs text-gray-500">Appears in header</p>
                            </div>
                            <div className="flex items-center gap-3">
                                {logo && <img src={logo} alt="Preview" className="h-10 w-10 object-contain rounded border bg-white"/>}
                                <label className="cursor-pointer bg-primary-600 text-white p-2 rounded hover:bg-primary-700 transition-colors">
                                    <i className="fas fa-upload"></i>
                                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, onUpdateLogo)}/>
                                </label>
                            </div>
                        </div>
                        <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-between">
                            <div>
                                <p className="font-bold text-sm">Hero Background</p>
                                <p className="text-xs text-gray-500">Main page hero image</p>
                            </div>
                            <div className="flex items-center gap-3">
                                {headerImage && <img src={headerImage} alt="Preview" className="h-10 w-10 object-cover rounded border bg-white"/>}
                                <label className="cursor-pointer bg-primary-600 text-white p-2 rounded hover:bg-primary-700 transition-colors">
                                    <i className="fas fa-upload"></i>
                                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, onUpdateHeaderImage)}/>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Share Settings */}
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg space-y-6">
                    <h3 className="text-xl font-bold flex items-center gap-2"><i className="fas fa-share-alt text-primary-500"></i> Sharing & Links</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-semibold mb-1">Official Website Link</label>
                            <div className="flex gap-2">
                                <input 
                                    type="text" 
                                    value={shareUrl} 
                                    onChange={(e) => onUpdateShareUrl(e.target.value)} 
                                    placeholder="https://..."
                                    className="form-input flex-grow p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
                                />
                                <button onClick={() => window.open(shareUrl, '_blank')} className="p-2 bg-gray-100 dark:bg-gray-700 rounded hover:bg-gray-200"><i className="fas fa-external-link-alt"></i></button>
                            </div>
                            <p className="text-[10px] text-gray-500 mt-1">This link will be used for QR generation if no custom image is provided.</p>
                        </div>
                        <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-between">
                            <div>
                                <p className="font-bold text-sm">Custom QR Code Image</p>
                                <p className="text-xs text-gray-500">Override auto-generated QR</p>
                            </div>
                            <div className="flex items-center gap-3">
                                {shareQr && <img src={shareQr} alt="QR Preview" className="h-10 w-10 object-contain rounded border bg-white"/>}
                                {shareQr && <button onClick={() => onUpdateShareQr('')} className="text-red-500 hover:text-red-700 p-2"><i className="fas fa-times-circle"></i></button>}
                                <label className="cursor-pointer bg-primary-600 text-white p-2 rounded hover:bg-primary-700 transition-colors">
                                    <i className="fas fa-qrcode"></i>
                                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, onUpdateShareQr)}/>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Student Modal */}
            <Modal isOpen={isStudentModalOpen} onClose={() => setStudentModalOpen(false)} title={editingStudent?.rank === 0 ? "Add New Student" : "Edit Student"}>
                {editingStudent && (
                    <div className="space-y-4">
                        <input type="text" placeholder="Admit Number" disabled={editingStudent.rank !== 0} value={editingStudent.admitNumber} onChange={e => setEditingStudent({...editingStudent, admitNumber: e.target.value})} className="form-input w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"/>
                        <input type="text" placeholder="Name" value={editingStudent.name} onChange={e => setEditingStudent({...editingStudent, name: e.target.value})} className="form-input w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"/>
                        <input type="number" placeholder="Class" value={editingStudent.class} onChange={e => setEditingStudent({...editingStudent, class: parseInt(e.target.value, 10) || 1})} className="form-input w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"/>
                        <input type="number" placeholder="Marks" value={editingStudent.marks} onChange={e => setEditingStudent({...editingStudent, marks: parseInt(e.target.value, 10) || 0})} className="form-input w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"/>
                        <StyledButton onClick={handleSaveStudent} className="w-full">Save Student</StyledButton>
                    </div>
                )}
            </Modal>

            {/* Notice Modal */}
            <Modal isOpen={isNoticeModalOpen} onClose={() => setNoticeModalOpen(false)} title={editingNotice?.id ? "Edit Notice" : "Add Notice"}>
                {editingNotice && (
                    <div className="space-y-4">
                        <div className="flex border-b dark:border-gray-700">
                             <button 
                                onClick={() => setIsNoticePreview(false)} 
                                className={`flex-1 py-2 font-bold text-sm transition-colors ${!isNoticePreview ? 'border-b-2 border-primary-500 text-primary-600' : 'text-gray-500'}`}
                             >
                                <i className="fas fa-edit mr-2"></i>Edit
                             </button>
                             <button 
                                onClick={() => setIsNoticePreview(true)} 
                                className={`flex-1 py-2 font-bold text-sm transition-colors ${isNoticePreview ? 'border-b-2 border-primary-500 text-primary-600' : 'text-gray-500'}`}
                             >
                                <i className="fas fa-eye mr-2"></i>Preview
                             </button>
                        </div>
                        
                        {!isNoticePreview ? (
                            <div className="space-y-4 animate-content-fade-in">
                                <div>
                                    <label className="block text-sm font-semibold mb-1 text-gray-700 dark:text-gray-300">Notice Title</label>
                                    <input type="text" value={editingNotice.title} onChange={e => setEditingNotice({...editingNotice, title: e.target.value})} className="form-input w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600" placeholder="e.g., Result Declaration Date"/>
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold mb-1 text-gray-700 dark:text-gray-300">Publication Date</label>
                                    <input 
                                        type="date" 
                                        value={editingNotice.date} 
                                        onChange={e => setEditingNotice({...editingNotice, date: e.target.value})} 
                                        className="form-input w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold mb-1 text-gray-700 dark:text-gray-300">Notice Content</label>
                                    <div className="border dark:border-gray-600 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-primary-500 transition-all">
                                        <div className="bg-gray-50 dark:bg-gray-700 border-b dark:border-gray-600 p-2 flex space-x-2">
                                            <button onClick={() => injectFormatting('<b>', '</b>')} className="w-8 h-8 rounded hover:bg-gray-200 dark:hover:bg-gray-600 flex items-center justify-center font-bold" title="Bold">B</button>
                                            <button onClick={() => injectFormatting('<i>', '</i>')} className="w-8 h-8 rounded hover:bg-gray-200 dark:hover:bg-gray-600 flex items-center justify-center italic" title="Italic">I</button>
                                            <button onClick={() => injectFormatting('• ', '')} className="w-8 h-8 rounded hover:bg-gray-200 dark:hover:bg-gray-600 flex items-center justify-center" title="Bullet Point">•</button>
                                            <div className="w-px h-6 bg-gray-300 dark:bg-gray-500 self-center"></div>
                                            <button onClick={() => setEditingNotice({...editingNotice, content: ''})} className="w-8 h-8 rounded hover:bg-red-100 hover:text-red-600 flex items-center justify-center" title="Clear Content"><i className="fas fa-eraser"></i></button>
                                        </div>
                                        <textarea 
                                            ref={noticeContentRef}
                                            value={editingNotice.content} 
                                            onChange={e => setEditingNotice({...editingNotice, content: e.target.value})} 
                                            rows={8} 
                                            className="w-full p-3 border-none bg-white dark:bg-gray-700 focus:ring-0 text-gray-800 dark:text-gray-100 placeholder-gray-400" 
                                            placeholder="Enter full details here. Use toolbar for formatting..."
                                        ></textarea>
                                    </div>
                                    <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-bold">Tip: Basic HTML tags like &lt;b&gt; and &lt;i&gt; are supported.</p>
                                </div>
                            </div>
                        ) : (
                            <div className="space-y-4 animate-content-fade-in">
                                <div className="p-6 bg-gray-50 dark:bg-gray-900/50 rounded-xl border border-dashed border-gray-300 dark:border-gray-700">
                                    <h4 className="text-primary-600 dark:text-primary-400 font-extrabold text-2xl mb-1">{editingNotice.title || 'No Title'}</h4>
                                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-4 uppercase tracking-widest flex items-center">
                                        <i className="fas fa-calendar-check mr-2"></i>
                                        {new Date(editingNotice.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                                        {editingNotice.date > todayStr && (
                                            <span className="ml-3 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-300 px-2 py-0.5 rounded text-[10px] font-bold">SCHEDULED</span>
                                        )}
                                    </p>
                                    <div 
                                        className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed prose dark:prose-invert max-w-none"
                                        dangerouslySetInnerHTML={{ __html: editingNotice.content || '<i class="text-gray-400">No content provided yet.</i>' }}
                                    ></div>
                                </div>
                                <div className="text-center">
                                    <button onClick={() => setIsNoticePreview(false)} className="text-primary-600 dark:text-primary-400 font-semibold hover:underline"><i className="fas fa-pencil mr-1"></i> Continue Editing</button>
                                </div>
                            </div>
                        )}
                        <StyledButton onClick={handleSaveNotice} className="w-full shadow-lg" icon="fas fa-save">Save Notice</StyledButton>
                    </div>
                )}
            </Modal>

            {/* Delete Confirmation (Students) */}
            <Modal isOpen={isDeleteConfirmOpen} onClose={() => setDeleteConfirmOpen(false)} title="Confirm Deletion">
                <div className="text-center">
                    <p className="mb-6 text-lg">Are you sure you want to delete <br/><strong>{studentToDelete?.name}</strong>?</p>
                    <div className="flex justify-center space-x-4">
                        <button onClick={() => setDeleteConfirmOpen(false)} className="py-2 px-6 bg-gray-200 dark:bg-gray-600 rounded-lg">Cancel</button>
                        <button onClick={handleConfirmDelete} className="py-2 px-6 bg-red-600 text-white rounded-lg shadow-md">Confirm Delete</button>
                    </div>
                </div>
            </Modal>

            {/* Delete Confirmation (Notices) */}
            <Modal isOpen={isNoticeDeleteConfirmOpen} onClose={() => setNoticeDeleteConfirmOpen(false)} title="Delete Notice">
                <div className="text-center">
                    <p className="mb-6 text-lg">Delete the notice: <br/><strong>{noticeToDelete?.title}</strong>?</p>
                    <div className="flex justify-center space-x-4">
                        <button onClick={() => setNoticeDeleteConfirmOpen(false)} className="py-2 px-6 bg-gray-200 dark:bg-gray-600 rounded-lg">Cancel</button>
                        <button onClick={handleConfirmDeleteNotice} className="py-2 px-6 bg-red-600 text-white rounded-lg shadow-md">Delete Notice</button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

const ArchiveView: React.FC<{ archives: YearArchive[], type: 'results' | 'questions', onBack: () => void }> = ({ archives, type, onBack }) => {
    const safeArchives = Array.isArray(archives) ? archives : [];
    const [selectedYear, setSelectedYear] = useState<number | null>(safeArchives.length > 0 ? safeArchives[0].year : null);
    const selectedArchive = safeArchives.find(a => a.year === selectedYear);

    return (
        <div className="p-4 md:p-8 animate-content-fade-in">
            <StyledButton onClick={onBack} icon="fas fa-arrow-left" className="mb-6">Back to Home</StyledButton>
            <h2 className="text-3xl font-bold mb-6 text-center text-gray-800 dark:text-gray-100">
                {type === 'results' ? 'Archived Results' : 'Archived Question Papers'}
            </h2>
             <div className="mb-6 max-w-xs mx-auto">
                <label htmlFor="year-select" className="sr-only">Select Year</label>
                <select
                    id="year-select"
                    value={selectedYear || ''}
                    onChange={(e) => setSelectedYear(Number(e.target.value))}
                    className="form-select w-full p-3 rounded-lg border-2 border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                >
                    {safeArchives.map(a => (
                        <option key={a.year} value={a.year}>
                            {a.year} Results
                        </option>
                    ))}
                </select>
            </div>

            {selectedArchive ? (
                type === 'results' ? (
                     <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg">
                        <ResultsView results={selectedArchive.results} onBack={() => {}} isArchive={true}/>
                    </div>
                ) : (
                    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
                        <h3 className="text-xl font-bold mb-4">Question Paper - {selectedArchive.year}</h3>
                        <pre className="whitespace-pre-wrap font-sans bg-gray-50 dark:bg-gray-700 p-4 rounded-md transition-all duration-300 hover:shadow-lg hover:-translate-y-1">{selectedArchive.questionPaper}</pre>
                    </div>
                )
            ) : <p className="text-center text-gray-500 dark:text-gray-400">No data available for the selected year.</p>}
        </div>
    );
};

const HomePage: React.FC<{ setView: (view: AppView) => void, onShowNotices: () => void, logoUrl: string, headerImageUrl: string, shareUrl: string, shareQr: string }> = ({ setView, onShowNotices, logoUrl, headerImageUrl, shareUrl, shareQr }) => {
    const finalShareUrl = shareUrl || window.location.href;
    const finalQrCodeUrl = shareQr || `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(finalShareUrl)}`;
    
    useEffect(() => {
        const glowingButtons = document.querySelectorAll('.glowing-btn');
        const handleMouseMove = (e: MouseEvent) => {
            const target = e.currentTarget as HTMLElement;
            const rect = target.getBoundingClientRect();
            const x = (e as any).clientX - rect.left;
            const y = (e as any).clientY - rect.top;
            target.style.setProperty('--x', `${x}px`);
            target.style.setProperty('--y', `${y}px`);
        };
        glowingButtons.forEach(button => button.addEventListener('mousemove', handleMouseMove as EventListener));
        return () => glowingButtons.forEach(button => button.removeEventListener('mousemove', handleMouseMove as EventListener));
    }, []);

    const copyLink = () => {
        navigator.clipboard.writeText(finalShareUrl);
        alert('Link copied to clipboard!');
    };

    return (
        <div 
          className="min-h-screen bg-cover bg-center"
          style={{ backgroundImage: `url(${headerImageUrl})`}}
        >
          <div className="min-h-screen flex flex-col items-center justify-center text-center p-4 pt-24 space-y-8 bg-black/60">
             {logoUrl && <img src={logoUrl} alt="Logo" className="h-32 w-32 object-contain mb-4"/>}
             <h2 className="text-4xl md:text-5xl font-extrabold text-white drop-shadow-lg animate-content-fade-in">Welcome to Pindrui Medha Anwesha</h2>
             <p className="max-w-2xl text-lg text-gray-200 animate-content-fade-in" style={{animationDelay: '100ms'}}>Your one-stop portal for exam results, notices, and updates from the Kojagori Lakshmi Puja Committee.</p>
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl animate-content-fade-in" style={{animationDelay: '200ms'}}>
                <button 
                    onClick={onShowNotices} 
                    className="glowing-btn group bg-gradient-to-br from-amber-400 to-orange-500 text-white py-6 px-4 rounded-lg shadow-lg"
                    style={{'--glow-color': 'rgba(251, 191, 36, 0.6)'} as any}
                >
                    <i className="fas fa-bullhorn fa-2x mb-2"></i><span className="block font-bold text-xl">Notices</span>
                </button>
                <button 
                    onClick={() => setView(AppView.RESULTS)} 
                    className="glowing-btn group bg-gradient-to-br from-green-400 to-emerald-500 text-white py-6 px-4 rounded-lg shadow-lg"
                    style={{'--glow-color': 'rgba(52, 211, 153, 0.6)'} as any}
                >
                    <i className="fas fa-poll fa-2x mb-2"></i><span className="block font-bold text-xl">Check Results</span>
                </button>
                 <button 
                    onClick={() => setView(AppView.HOST_LOGIN)} 
                    className="glowing-btn group bg-gradient-to-br from-rose-500 to-red-600 text-white py-6 px-4 rounded-lg shadow-lg"
                    style={{'--glow-color': 'rgba(244, 63, 94, 0.6)'} as any}
                 >
                    <i className="fas fa-user-shield fa-2x mb-2"></i><span className="block font-bold text-xl">Host Access</span>
                </button>
             </div>
             <div className="pt-8 animate-content-fade-in" style={{animationDelay: '300ms'}}>
                <h3 className="text-xl font-bold mb-4 text-white">Share Portal</h3>
                <div className="flex flex-col md:flex-row items-center justify-center gap-6 bg-white/90 p-4 rounded-lg shadow-lg backdrop-blur-sm">
                    <img src={finalQrCodeUrl} alt="QR" className="w-32 h-32 object-contain bg-white p-1 rounded"/>
                    <div className="flex flex-col items-center gap-2">
                        <span className="text-gray-800 font-semibold truncate max-w-[200px]">{finalShareUrl}</span>
                        <button onClick={copyLink} className="bg-primary-600 text-white py-2 px-4 rounded-full flex items-center gap-2 transition-transform hover:scale-105"><i className="fas fa-link"></i> Copy Link</button>
                    </div>
                </div>
            </div>
          </div>
        </div>
    );
};

// Routing logic
const viewToSlug = (view: AppView): string => {
    switch (view) {
        case AppView.RESULTS: return 'results';
        case AppView.HOST_LOGIN: return 'host-login';
        case AppView.ARCHIVE_RESULTS: return 'archive-results';
        case AppView.ARCHIVE_QUESTIONS: return 'archive-questions';
        case AppView.HOST_SIGNUP: return 'signup';
        case AppView.HOST_FORGOT_PASSWORD: return 'reset-password';
        case AppView.UPDATES: return 'updates';
        case AppView.NOTICES: return 'notices';
        default: return '';
    }
};

const slugToView = (slug: string): AppView | null => {
    switch (slug) {
        case 'results': return AppView.RESULTS;
        case 'host-login': return AppView.HOST_LOGIN;
        case 'archive-results': return AppView.ARCHIVE_RESULTS;
        case 'archive-questions': return AppView.ARCHIVE_QUESTIONS;
        case 'signup': return AppView.HOST_SIGNUP;
        case 'reset-password': return AppView.HOST_FORGOT_PASSWORD;
        case 'updates': return AppView.UPDATES;
        case 'notices': return AppView.NOTICES;
        default: return null;
    }
};

export default function App() {
    const [view, setView] = useState<AppView>(AppView.HOME);
    const [isMenuOpen, setMenuOpen] = useState(false);
    const [isHost, setIsHost] = useState(false);
    const [isDarkMode, setIsDarkMode] = useState(false);
    const [isNoticeModalOpen, setNoticeModalOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const [isDiscoMode, setIsDiscoMode] = useState(false);
    const [isZoomEffectEnabled, setIsZoomEffectEnabled] = useState(false);
    
    // Data states
    const [logo, setLogo] = useState('');
    const [headerImage, setHeaderImage] = useState('');
    const [results, setResults] = useState<StudentResult[]>([]);
    const [archives, setArchives] = useState<YearArchive[]>(MOCK_ARCHIVES);
    const [notices, setNotices] = useState<Notice[]>([]);
    const [shareUrl, setShareUrl] = useState('');
    const [shareQr, setShareQr] = useState('');

    // URL Parsing & History
    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const viewSlug = params.get('view');
        if (viewSlug) {
            const initialView = slugToView(viewSlug);
            if (initialView !== null) {
                if (initialView === AppView.NOTICES) setNoticeModalOpen(true);
                else setView(initialView);
            }
        }
        
        const handlePopState = () => {
             const p = new URLSearchParams(window.location.search);
             const slug = p.get('view');
             const nv = slug ? slugToView(slug) : AppView.HOME;
             if (nv !== null) {
                 setView(nv);
                 setNoticeModalOpen(nv === AppView.NOTICES);
             }
        };
        window.addEventListener('popstate', handlePopState);
        return () => window.removeEventListener('popstate', handlePopState);
    }, []);

    const updateUrl = useCallback((newView: AppView) => {
        const slug = viewToSlug(newView);
        const params = new URLSearchParams(window.location.search);
        if (newView !== AppView.RESULTS) params.delete('class');
        if (slug) params.set('view', slug);
        else params.delete('view');
        const currentSlug = new URLSearchParams(window.location.search).get('view');
        if (currentSlug !== slug) window.history.pushState({ view: newView }, '', `?${params.toString()}`);
    }, []);

    const handleSetView = useCallback((newView: AppView) => {
        if (newView === AppView.NOTICES) setNoticeModalOpen(true);
        else {
            setNoticeModalOpen(false);
            setView(newView);
        }
        updateUrl(newView);
    }, [updateUrl]);

    // DB Operations
    const updateResultsAndRanks = useCallback(async (newResults: StudentResult[]) => {
        const sorted = [...newResults].sort((a, b) => b.marks - a.marks);
        const ranked = sorted.map((s, i, arr) => {
            let rank = i + 1;
            if (i > 0 && s.marks === arr[i - 1].marks) {
                // Find first occurrence of this score in the sorted list
                const firstIdx = arr.findIndex(x => x.marks === s.marks);
                rank = firstIdx + 1;
            }
            return { ...s, rank };
        });
        setResults(ranked);
        await databaseService.saveResults(ranked);
    }, []);

    const updateNotices = useCallback(async (newNotices: Notice[]) => {
        setNotices(newNotices);
        await databaseService.saveNotices(newNotices);
    }, []);

    useEffect(() => {
        databaseService.initializeDatabase();
        const load = async () => {
            const res = await databaseService.getResults();
            const log = await databaseService.getLogo();
            const hImg = await databaseService.getHeaderImage();
            const nots = await databaseService.getNotices();
            const sUrl = await databaseService.getShareUrl();
            const sQr = await databaseService.getShareQr();
            setResults(res);
            setLogo(log);
            setHeaderImage(hImg);
            setNotices(nots);
            setShareUrl(sUrl);
            setShareQr(sQr);
        };
        load();
    }, []);

    // Visual Effects
    useEffect(() => {
        const spotlightEl = document.getElementById('spotlight');
        if (!spotlightEl) return;
        const move = (e: MouseEvent) => {
            requestAnimationFrame(() => {
                spotlightEl.style.left = `${e.clientX}px`;
                spotlightEl.style.top = `${e.clientY}px`;
            });
        };
        window.addEventListener('mousemove', move);
        return () => window.removeEventListener('mousemove', move);
    }, []);
    
    useEffect(() => {
        const scroll = () => setIsScrolled(window.scrollY > 10);
        window.addEventListener('scroll', scroll, { passive: true });
        return () => window.removeEventListener('scroll', scroll);
    }, []);

    useEffect(() => {
        const isDark = localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
        setIsDarkMode(isDark);
        if (isDark) document.documentElement.classList.add('dark');
    }, []);

    const toggleTheme = () => {
        setIsDarkMode(prev => {
            const nv = !prev;
            document.documentElement.classList.toggle('dark', nv);
            localStorage.setItem('theme', nv ? 'dark' : 'light');
            return nv;
        });
    };
    
    // Filter out future notices for public view & sort by date descending
    const todayStr = getLocalDateString(new Date());
    const safeNoticesForView = Array.isArray(notices) ? notices : [];
    const sortedPublicNotices = safeNoticesForView
        .filter(n => n.date <= todayStr)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-slate-900 text-gray-900 dark:text-gray-100 font-sans transition-colors duration-300">
            <Header onMenuClick={() => setMenuOpen(true)} logoUrl={logo} isScrolled={isScrolled} toggleTheme={toggleTheme} isDarkMode={isDarkMode} />
            <SideMenu 
                isOpen={isMenuOpen} onClose={() => setMenuOpen(false)} setView={handleSetView} toggleTheme={toggleTheme} 
                isDarkMode={isDarkMode} isDiscoMode={isDiscoMode} toggleDiscoMode={() => setIsDiscoMode(!isDiscoMode)}
                isZoomEffectEnabled={isZoomEffectEnabled} toggleZoomEffect={() => setIsZoomEffectEnabled(!isZoomEffectEnabled)}
             />
            
            <main className={view === AppView.HOME ? '' : 'pt-20'}>
                <div key={view} className={view !== AppView.HOME ? 'animate-content-fade-in' : ''}>
                    {isHost ? (
                        <HostDashboard 
                            results={results} archives={archives} notices={notices} logo={logo} headerImage={headerImage}
                            shareUrl={shareUrl} shareQr={shareQr}
                            onUpdateResults={updateResultsAndRanks} onUpdateArchives={setArchives}
                            onUpdateNotices={updateNotices} onUpdateLogo={async (u) => {setLogo(u); await databaseService.saveLogo(u);}} 
                            onUpdateHeaderImage={async (u) => {setHeaderImage(u); await databaseService.saveHeaderImage(u);}}
                            onUpdateShareUrl={async (u) => {setShareUrl(u); await databaseService.saveShareUrl(u);}}
                            onUpdateShareQr={async (u) => {setShareQr(u); await databaseService.saveShareQr(u);}}
                            onLogout={() => {setIsHost(false); setView(AppView.HOME);}} onBack={() => {setIsHost(false); setView(AppView.HOME);}}
                        />
                    ) : (
                        view === AppView.RESULTS ? <ResultsView results={results} onBack={() => handleSetView(AppView.HOME)} /> :
                        view === AppView.HOST_LOGIN ? <HostLogin onLoginSuccess={() => setIsHost(true)} onBack={() => handleSetView(AppView.HOME)} onForgotPassword={() => handleSetView(AppView.HOST_FORGOT_PASSWORD)} onCreateAccount={() => handleSetView(AppView.HOST_SIGNUP)} /> :
                        view === AppView.HOST_FORGOT_PASSWORD ? <ForgotPasswordView onPasswordReset={async (m, p) => {await databaseService.updateHostPassword(m, p); alert('Success!'); handleSetView(AppView.HOST_LOGIN);}} onBack={() => handleSetView(AppView.HOST_LOGIN)} /> :
                        view === AppView.HOST_SIGNUP ? <HostSignUp onRegister={async (c) => {await databaseService.addHost(c); alert('Success!'); handleSetView(AppView.HOST_LOGIN);}} onBack={() => handleSetView(AppView.HOST_LOGIN)} /> :
                        view === AppView.ARCHIVE_RESULTS ? <ArchiveView archives={archives} type="results" onBack={() => handleSetView(AppView.HOME)} /> :
                        view === AppView.ARCHIVE_QUESTIONS ? <ArchiveView archives={archives} type="questions" onBack={() => handleSetView(AppView.HOME)} /> :
                        <HomePage setView={handleSetView} onShowNotices={() => handleSetView(AppView.NOTICES)} logoUrl={logo} headerImageUrl={headerImage} shareUrl={shareUrl} shareQr={shareQr} />
                    )}
                </div>
            </main>
            
            <Modal isOpen={isNoticeModalOpen} onClose={() => { setNoticeModalOpen(false); if(view === AppView.NOTICES) handleSetView(AppView.HOME); }} title="Latest Notices">
                <div className="space-y-4">
                    {sortedPublicNotices.map(n => (
                        <div key={n.id} className="p-4 bg-gray-100 dark:bg-gray-700 rounded-lg transition-all border-l-4 border-primary-500 shadow-sm animate-content-fade-in">
                            <h3 className="font-bold text-lg text-primary-600 dark:text-primary-400">{n.title}</h3>
                            <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2">
                                <i className="fas fa-calendar-alt mr-2"></i>
                                {new Date(n.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                            </p>
                            <div 
                                className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed prose dark:prose-invert max-w-none"
                                dangerouslySetInnerHTML={{ __html: n.content }}
                            ></div>
                        </div>
                    ))}
                    {sortedPublicNotices.length === 0 && (
                        <div className="text-center py-8">
                            <i className="fas fa-info-circle fa-3x text-gray-300 mb-4"></i>
                            <p className="text-gray-500">No new notices at this time. Please check back later.</p>
                        </div>
                    )}
                </div>
            </Modal>
            
            <AiAssistant />
        </div>
    );
}
