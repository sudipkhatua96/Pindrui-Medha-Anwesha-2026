import React, { useState, useRef, useEffect } from 'react';
import { getAiResponse, AiSource } from '../services/geminiService';

interface Message {
    role: 'user' | 'model';
    parts: { text: string }[];
    sources?: AiSource[];
}

const AiAssistant: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<null | HTMLDivElement>(null);

    useEffect(() => {
        const savedHistory = localStorage.getItem('ai_chat_history');
        if (savedHistory) {
            setMessages(JSON.parse(savedHistory));
        }
    }, []);

    useEffect(() => {
        if (messages.length > 0) {
            localStorage.setItem('ai_chat_history', JSON.stringify(messages));
        }
    }, [messages]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleClearChat = () => {
        setMessages([]);
        localStorage.removeItem('ai_chat_history');
    }

    const handleSend = async () => {
        if (input.trim() === '' || isLoading) return;

        const userMessage: Message = { role: 'user', parts: [{ text: input }] };
        const newMessages = [...messages, userMessage];
        
        setMessages(newMessages);
        setInput('');
        setIsLoading(true);
        
        const historyForAPI = newMessages.map(({ role, parts }) => ({ role, parts }));
        const { text: responseText, sources } = await getAiResponse(input, historyForAPI);

        const modelMessage: Message = { 
            role: 'model', 
            parts: [{ text: responseText }],
            sources,
        };

        setMessages(prev => [...prev, modelMessage]);
        setIsLoading(false);
    };

    return (
        <>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="fixed bottom-5 right-5 bg-primary-600 text-white rounded-full h-16 w-16 flex items-center justify-center shadow-lg hover:bg-primary-700 transition-transform transform hover:scale-110 z-40 animate-pulse-glow"
                aria-label="Toggle AI Assistant"
            >
                <i className="fas fa-robot fa-2x"></i>
            </button>

            {isOpen && (
                <div className="fixed bottom-24 right-5 w-full max-w-sm h-[60vh] bg-white dark:bg-gray-800 rounded-lg shadow-2xl flex flex-col z-40 animate-content-fade-in">
                    <div className="flex justify-between items-center p-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-t-lg">
                        <h3 className="font-bold text-lg">Medha Assistant</h3>
                        <div>
                             <button onClick={handleClearChat} className="text-white hover:text-gray-200 mr-3" aria-label="Clear chat">
                               <i className="fas fa-trash"></i>
                            </button>
                            <button onClick={() => setIsOpen(false)} className="text-white hover:text-gray-200" aria-label="Close chat">
                               <i className="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div className="flex-1 p-4 overflow-y-auto space-y-4">
                        {messages.length === 0 && (
                             <div className="flex justify-center items-center h-full">
                                <div className="text-center text-gray-500 dark:text-gray-400">
                                    <i className="fas fa-comments fa-3x mb-2"></i>
                                    <p>Ask me anything!</p>
                                </div>
                            </div>
                        )}
                        {messages.map((msg, index) => (
                            <div key={index} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                                <div className={`max-w-xs md:max-w-sm rounded-lg px-4 py-2 shadow-sm ${msg.role === 'user' ? 'bg-primary-500 text-white rounded-br-none' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-none'}`}>
                                    <p className="whitespace-pre-wrap">{msg.parts[0].text}</p>
                                </div>
                                {msg.sources && msg.sources.length > 0 && (
                                    <div className="mt-2 max-w-xs md:max-w-sm text-xs text-gray-500 dark:text-gray-400">
                                        <p className="font-bold mb-1">Sources:</p>
                                        <ul className="space-y-1 list-disc list-inside">
                                            {msg.sources.map((source, i) => (
                                                <li key={i}>
                                                    <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-primary-600 dark:text-primary-400 hover:underline">
                                                        {source.title}
                                                    </a>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        ))}
                         {isLoading && (
                            <div className="flex justify-start">
                                <div className="bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg rounded-bl-none px-4 py-2">
                                    <i className="fas fa-spinner fa-pulse"></i>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>
                    <div className="p-4 border-t dark:border-gray-700 flex items-center">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask me anything..."
                            className="flex-1 bg-gray-100 dark:bg-gray-600 border-transparent rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                        <button onClick={handleSend} disabled={isLoading} className="ml-3 bg-primary-600 text-white rounded-full h-10 w-10 flex items-center justify-center hover:bg-primary-700 disabled:bg-primary-300">
                            <i className="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </div>
            )}
        </>
    );
};

export default AiAssistant;