
import { YearArchive, Notice, StudentResult } from './types';

export const MOCK_ARCHIVES: YearArchive[] = [
  {
    year: 2023,
    results: [
        { admitNumber: '23001', name: 'Ayan Malik', class: 9, marks: 98, rank: 1 },
        { admitNumber: '23002', name: 'Mita Biswas', class: 8, marks: 95, rank: 2 },
    ],
    questionPaper: `Pindrui Medha Anwesha - 2023\n\nClass V - General Knowledge\n\n1. What is the capital of West Bengal?\n2. Who wrote the national anthem of India?`
  }
];

export const MOCK_NOTICES: Notice[] = [
    {
        id: '1',
        title: 'Kojagori Lakshmi Puja Schedule',
        content: 'The annual Kojagori Lakshmi Puja will be held on 28th October. All are welcome. Prasad distribution will start from 8 PM onwards.',
        date: '2024-10-15',
    }
];