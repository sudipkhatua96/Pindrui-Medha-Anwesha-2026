const OTP_STORAGE_KEY = 'otp_verification';

interface OtpData {
    otp: string;
    timestamp: number;
}

/**
 * Simulates sending an OTP to a mobile number.
 * In a real application, this would use an SMS gateway like Twilio.
 * Here, we generate a random OTP, store it in sessionStorage, and log it to the console.
 * @param mobile The mobile number to send the OTP to.
 * @returns The generated OTP.
 */
export async function sendOtp(mobile: string): Promise<string> {
    const otp = Math.floor(1000 + Math.random() * 9000).toString(); // Generate 4-digit OTP
    const otpData: OtpData = { otp, timestamp: Date.now() };
    
    // Store OTP in sessionStorage for verification
    sessionStorage.setItem(OTP_STORAGE_KEY, JSON.stringify(otpData));

    // Simulate sending OTP
    console.log(`--- OTP Service Simulation ---`);
    console.log(`OTP for mobile number ${mobile}: ${otp}`);
    console.log(`This would be sent via SMS in a real app.`);
    console.log(`------------------------------`);

    alert(`An OTP has been sent. Check the developer console for the OTP. (Hint: ${otp})`);

    return otp;
}

/**
 * Verifies the submitted OTP against the stored one.
 * @param submittedOtp The OTP entered by the user.
 * @returns True if the OTP is valid and not expired, false otherwise.
 */
export async function verifyOtp(submittedOtp: string): Promise<boolean> {
    const otpDataJson = sessionStorage.getItem(OTP_STORAGE_KEY);
    if (!otpDataJson) {
        return false;
    }

    const otpData: OtpData = JSON.parse(otpDataJson);
    const OTP_EXPIRATION_MINUTES = 5;
    const isExpired = (Date.now() - otpData.timestamp) > OTP_EXPIRATION_MINUTES * 60 * 1000;

    if (isExpired) {
        sessionStorage.removeItem(OTP_STORAGE_KEY);
        console.warn("OTP has expired.");
        return false;
    }

    if (otpData.otp === submittedOtp) {
        sessionStorage.removeItem(OTP_STORAGE_KEY); // OTP is single-use
        return true;
    }

    return false;
}
