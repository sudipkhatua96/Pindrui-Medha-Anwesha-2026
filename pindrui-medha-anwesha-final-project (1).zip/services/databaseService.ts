
import { StudentResult, HostCredential, Notice } from '../types';

// This mock data is now only used to seed the database on the first run.
const MOCK_RESULTS_2024: StudentResult[] = [
  { admitNumber: '24001', name: 'Sudip Khatua', class: 10, marks: 95, rank: 1 },
  { admitNumber: '24002', name: 'Rahul Karmakar', class: 9, marks: 92, rank: 2 },
  { admitNumber: '24003', name: 'Priya Saha', class: 10, marks: 90, rank: 3 },
  { admitNumber: '24004', name: 'Sourav Ghosh', class: 8, marks: 88, rank: 4 },
  { admitNumber: '24005', name: 'Sneha Roy', class: 9, marks: 85, rank: 5 },
  { admitNumber: '24006', name: 'Bikash Mondal', class: 7, marks: 84, rank: 6 },
  { admitNumber: '24007', name: 'Rima Pal', class: 10, marks: 82, rank: 7 },
  { admitNumber: '24008', name: 'Amit Kumar', class: 6, marks: 80, rank: 8 },
  { admitNumber: '24009', name: 'Tania Bera', class: 8, marks: 78, rank: 9 },
  { admitNumber: '24010', name: 'Rajib Barman', class: 9, marks: 75, rank: 10 },
];

const DB_KEYS = {
    RESULTS: 'db_results',
    HOSTS: 'db_hosts',
    NOTICES: 'db_notices',
    INITIALIZED: 'db_initialized',
    LOGO: 'db_logo',
    HEADER_IMAGE: 'db_header_image',
    SHARE_URL: 'db_share_url',
    SHARE_QR: 'db_share_qr',
};

const INITIAL_HOSTS: HostCredential[] = [
    { mobile: '1234567890', password: 'password123' }
];

const INITIAL_NOTICES: Notice[] = [
    {
        id: '1',
        title: 'Kojagori Lakshmi Puja Schedule',
        content: 'The annual Kojagori Lakshmi Puja will be held on 28th October. All are welcome. Prasad distribution will start from 8 PM onwards.',
        date: '2024-10-15',
    }
];

const INITIAL_LOGO = 'https://i.ibb.co/9gX12bS/logo.png';
const INITIAL_HEADER_IMAGE = 'https://images.unsplash.com/photo-1557682250-33bd709cbe85?q=80&w=2070&auto=format&fit=crop';


// --- Database Initialization ---
export function initializeDatabase() {
    if (!localStorage.getItem(DB_KEYS.INITIALIZED)) {
        console.log("Initializing database in localStorage for the first time...");
        localStorage.setItem(DB_KEYS.RESULTS, JSON.stringify(MOCK_RESULTS_2024));
        localStorage.setItem(DB_KEYS.HOSTS, JSON.stringify(INITIAL_HOSTS));
        localStorage.setItem(DB_KEYS.NOTICES, JSON.stringify(INITIAL_NOTICES));
        localStorage.setItem(DB_KEYS.LOGO, INITIAL_LOGO);
        localStorage.setItem(DB_KEYS.HEADER_IMAGE, INITIAL_HEADER_IMAGE);
        localStorage.setItem(DB_KEYS.SHARE_URL, window.location.origin);
        localStorage.setItem(DB_KEYS.SHARE_QR, '');
        localStorage.setItem(DB_KEYS.INITIALIZED, 'true');
    }
}

// --- Results Management ---
export async function getResults(): Promise<StudentResult[]> {
    try {
        const resultsJson = localStorage.getItem(DB_KEYS.RESULTS);
        const results = resultsJson ? JSON.parse(resultsJson) : [];
        return Array.isArray(results) ? results : [];
    } catch (e) {
        console.error("Failed to parse results from DB", e);
        return [];
    }
}

export async function saveResults(results: StudentResult[]): Promise<void> {
    localStorage.setItem(DB_KEYS.RESULTS, JSON.stringify(results));
}

// --- Notices Management ---
export async function getNotices(): Promise<Notice[]> {
    try {
        const noticesJson = localStorage.getItem(DB_KEYS.NOTICES);
        const notices = noticesJson ? JSON.parse(noticesJson) : [];
        return Array.isArray(notices) ? notices : [];
    } catch (e) {
        console.error("Failed to parse notices from DB", e);
        return [];
    }
}

export async function saveNotices(notices: Notice[]): Promise<void> {
    localStorage.setItem(DB_KEYS.NOTICES, JSON.stringify(notices));
}

// --- Logo Management ---
export async function getLogo(): Promise<string> {
    return localStorage.getItem(DB_KEYS.LOGO) || INITIAL_LOGO;
}

export async function saveLogo(url: string): Promise<void> {
    localStorage.setItem(DB_KEYS.LOGO, url);
}

// --- Header Image Management ---
export async function getHeaderImage(): Promise<string> {
    return localStorage.getItem(DB_KEYS.HEADER_IMAGE) || INITIAL_HEADER_IMAGE;
}

export async function saveHeaderImage(url: string): Promise<void> {
    localStorage.setItem(DB_KEYS.HEADER_IMAGE, url);
}

// --- Share Settings Management ---
export async function getShareUrl(): Promise<string> {
    return localStorage.getItem(DB_KEYS.SHARE_URL) || window.location.origin;
}

export async function saveShareUrl(url: string): Promise<void> {
    localStorage.setItem(DB_KEYS.SHARE_URL, url);
}

export async function getShareQr(): Promise<string> {
    return localStorage.getItem(DB_KEYS.SHARE_QR) || '';
}

export async function saveShareQr(url: string): Promise<void> {
    localStorage.setItem(DB_KEYS.SHARE_QR, url);
}

// --- Host Management ---
export async function getHosts(): Promise<HostCredential[]> {
    const hostsJson = localStorage.getItem(DB_KEYS.HOSTS);
    return hostsJson ? JSON.parse(hostsJson) : [];
}

export async function addHost(newHost: HostCredential): Promise<void> {
    const hosts = await getHosts();
    if (hosts.some(h => h.mobile === newHost.mobile)) {
        throw new Error("A host with this mobile number already exists.");
    }
    const updatedHosts = [...hosts, newHost];
    localStorage.setItem(DB_KEYS.HOSTS, JSON.stringify(updatedHosts));
}

export async function getHostByMobile(mobile: string): Promise<HostCredential | undefined> {
    const hosts = await getHosts();
    return hosts.find(h => h.mobile === mobile);
}

export async function updateHostPassword(mobile: string, newPassword: string): Promise<void> {
    let hosts = await getHosts();
    const hostIndex = hosts.findIndex(h => h.mobile === mobile);
    if (hostIndex !== -1) {
        hosts[hostIndex].password = newPassword;
        localStorage.setItem(DB_KEYS.HOSTS, JSON.stringify(hosts));
    } else {
        throw new Error("Host not found.");
    }
}
