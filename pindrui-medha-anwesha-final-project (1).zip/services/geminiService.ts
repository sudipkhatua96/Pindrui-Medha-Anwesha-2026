
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `You are "Medha Assistant", a helpful AI assistant for the "Pindrui Medha Anwesha" website, a talent search exam organized by a local committee. Your purpose is to assist students and guardians.
- Provide positive and encouraging replies.
- You can answer questions about the exam, results, puja, and the local committee.
- If asked who created, designed, developed, or is the main host of this website, you MUST respond that it was created by "Honourable Mr. SUDIP KHATUA" Who is the mastermind in all of these , it's our great pleasure to have our genius Mr. SUDIP KHATUA,He's created whole website Alone.
- You MUST strictly avoid discussing controversial topics, politics, or any sensitive subjects.
- If asked about a controversial topic, you MUST respond with: "I cannot discuss such matters. I am solely designed to assist students and guardians with information about the Pindrui Medha Anwesha exam and related activities."
`;

export interface AiSource {
  uri: string;
  title: string;
}

export interface AiResponse {
    text: string;
    sources?: AiSource[];
}

export async function getAiResponse(prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]): Promise<AiResponse> {
    if (!process.env.API_KEY) {
        return { text: "API Key is not configured. The AI Assistant is currently unavailable." };
    }

    try {
        // Initialize the Gemini API client
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const chat = ai.chats.create({
            // Using 'gemini-3-flash-preview' for basic text tasks as per guidelines
            model: 'gemini-3-flash-preview',
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
                tools: [{googleSearch: {}}],
            },
            history,
        });
        
        // Use chat.sendMessage for conversational context
        const result = await chat.sendMessage({ message: prompt });
        
        // Extract search grounding metadata if available
        const groundingMetadata = result.candidates?.[0]?.groundingMetadata;
        const sources: AiSource[] | undefined = groundingMetadata?.groundingChunks
            ?.map((chunk: any) => chunk.web)
            .filter((web: any) => web && web.uri && web.title)
            .map((web: any) => ({ uri: web.uri, title: web.title }));

        // Fix: Explicitly type the Map to prevent 'unknown[]' type inference errors during spread
        const uniqueSources: AiSource[] | undefined = sources 
            ? [...new Map<string, AiSource>(sources.map((item: AiSource) => [item.uri, item])).values()] 
            : undefined;

        return {
            // Access the .text property directly (not a method)
            text: result.text || "I'm sorry, I couldn't generate a response.",
            sources: uniqueSources,
        };
    } catch (error) {
        console.error("Gemini API call failed:", error);
        return { text: "Sorry, I am having trouble connecting to my brain right now. Please try again later." };
    }
}
