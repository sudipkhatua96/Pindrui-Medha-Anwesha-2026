export enum AppView {
  HOME,
  RESULTS,
  HOST_LOGIN,
  HOST_DASHBOARD,
  ARCHIVE_RESULTS,
  ARCHIVE_QUESTIONS,
  NOTICES,
  UPDATES,
  HOST_FORGOT_PASSWORD,
  HOST_SIGNUP,
}

export interface StudentResult {
  admitNumber: string;
  name: string;
  class: number;
  marks: number;
  rank: number;
}

export interface YearArchive {
  year: number;
  results: StudentResult[];
  questionPaper: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: string;
}

export interface HostCredential {
  mobile: string;
  password: string;
}
